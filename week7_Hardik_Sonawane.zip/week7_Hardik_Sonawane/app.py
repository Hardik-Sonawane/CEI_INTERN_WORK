import os
import time
import numpy as np
from typing import List, Dict, Any, Tuple
from pypdf import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from rank_bm25 import BM25Okapi
from google import genai
from google.genai import types

try:
    import streamlit as st
except ImportError:
    st = None

# -----------------------------------------------------------------------------
# 1. CORE DATA STRUCTURES & INGESTION
# -----------------------------------------------------------------------------
class Document:
    def __init__(self, page_content: str, metadata: Dict[str, Any] = None):
        self.page_content = page_content
        self.metadata = metadata or {}

class MultiFormatIngestor:
    @staticmethod
    def ingest_pdf(file_stream, filename: str = "document.pdf") -> List[Document]:
        docs = []
        reader = PdfReader(file_stream)
        for i, page in enumerate(reader.pages, start=1):
            text = page.extract_text()
            if text and text.strip():
                docs.append(Document(page_content=text, metadata={"source": filename, "page": i}))
        return docs

    @staticmethod
    def ingest_docx(file_stream, filename: str = "document.docx") -> List[Document]:
        docs = []
        try:
            import docx
            doc = docx.Document(file_stream)
            full_text = [p.text for p in doc.paragraphs if p.text.strip()]
            if full_text:
                docs.append(Document(page_content="\n".join(full_text), metadata={"source": filename, "page": 1}))
        except Exception:
            pass
        return docs

    @staticmethod
    def ingest_txt(text_content: str, filename: str = "document.txt") -> List[Document]:
        if text_content and text_content.strip():
            return [Document(page_content=text_content.strip(), metadata={"source": filename, "page": 1})]
        return []

# -----------------------------------------------------------------------------
# 2. SIMPLE CHUNKER & VECTOR STORE
# -----------------------------------------------------------------------------
class SentenceBoundaryChunker:
    def __init__(self, target_chunk_size: int = 500, overlap_chars: int = 100):
        self.target_chunk_size = target_chunk_size
        self.overlap_chars = overlap_chars

    def chunk_documents(self, documents: List[Document]) -> List[Document]:
        chunked_docs = []
        for doc in documents:
            text = doc.page_content
            for start in range(0, len(text), self.target_chunk_size - self.overlap_chars):
                chunk_text = text[start:start + self.target_chunk_size]
                if chunk_text.strip():
                    chunked_docs.append(Document(page_content=chunk_text, metadata=doc.metadata))
        return chunked_docs

class SimpleVectorStore:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(max_features=384, stop_words='english')
        self.documents: List[Document] = []
        self.embeddings: np.ndarray = None

    def add_documents(self, documents: List[Document]):
        if not documents: return
        self.documents = documents
        texts = [doc.page_content for doc in documents]
        self.embeddings = self.vectorizer.fit_transform(texts).toarray()

    def similarity_search(self, query: str, top_k: int = 4) -> List[Tuple[Document, float]]:
        if not self.documents or self.embeddings is None: return []
        query_vec = self.vectorizer.transform([query]).toarray()
        scores = cosine_similarity(query_vec, self.embeddings)[0]
        top_indices = np.argsort(scores)[::-1][:top_k]
        return [(self.documents[idx], float(scores[idx])) for idx in top_indices]

class HybridRRFRetriever:
    def __init__(self, vector_store: SimpleVectorStore, documents: List[Document]):
        self.vector_store = vector_store
        self.documents = documents

    def retrieve(self, query: str, top_k: int = 4, use_hybrid: bool = True) -> List[Document]:
        results = self.vector_store.similarity_search(query, top_k=top_k)
        return [doc for doc, _ in results]

# -----------------------------------------------------------------------------
# 3. GROUNDED QA ENGINE
# -----------------------------------------------------------------------------
class GroundedRAGAnswerEngine:
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get("GOOGLE_API_KEY", "")
        self.client = None
        if self.api_key and len(self.api_key.strip()) > 10:
            self.client = genai.Client(api_key=self.api_key)

    def generate_answer(self, query: str, retriever: HybridRRFRetriever, top_k: int = 4, use_hybrid: bool = True) -> Tuple[str, List[Document]]:
        retrieved_docs = retriever.retrieve(query, top_k=top_k)
        if not retrieved_docs:
            return "No relevant context found in documents.", []

        context_str = "\n\n".join([f"[Source: {d.metadata.get('source', 'Doc')}]\n{d.page_content}" for d in retrieved_docs])
        prompt = f"Answer strictly using this context:\n{context_str}\n\nQuestion: {query}\nAnswer:"

        if not self.client:
            return "API Key missing. Showing retrieved chunks below:", retrieved_docs

        for model in ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.0-flash-lite"]:
            try:
                res = self.client.models.generate_content(model=model, contents=prompt)
                if res and res.text: return res.text.strip(), retrieved_docs
            except Exception:
                continue
        return "API Quota limit reached. Showing retrieved context chunks:", retrieved_docs

# -----------------------------------------------------------------------------
# 4. CLEAN STREAMLIT DASHBOARD (NO DEPLOY BUTTON, NO 3-DOT MENU)
# -----------------------------------------------------------------------------
if st is not None:
    st.set_page_config(page_title="RAG Document Q&A", layout="wide", initial_sidebar_state="expanded")

    # Clean styling: hide 3-dots, deploy button, header toolbars, and force white text on dark background
    st.markdown("""
    <style>
        #MainMenu {visibility: hidden !important; display: none !important;}
        footer {visibility: hidden !important; display: none !important;}
        header {visibility: hidden !important; display: none !important;}
        .stDeployButton {display: none !important; visibility: hidden !important;}
        [data-testid="stToolbar"] {visibility: hidden !important; display: none !important;}
        [data-testid="stDecoration"] {display: none !important; visibility: hidden !important;}
        [data-testid="stHeader"] {display: none !important; visibility: hidden !important;}
        div[class*="stActionButton"] {display: none !important; visibility: hidden !important;}
        div[data-testid="stStatusWidget"] {display: none !important; visibility: hidden !important;}
        
        .main, .stApp { background-color: #0e1117 !important; color: #ffffff !important; }
        p, span, h1, h2, h3, h4, h5, h6, label, div { color: #ffffff !important; }
        [data-testid="stChatMessage"] { background-color: #1e2530 !important; color: #ffffff !important; }
        [data-testid="stChatMessage"] p { color: #ffffff !important; }
        [data-testid="stExpander"] { background-color: #161b22 !important; border: 1px solid #30363d !important; }
        [data-testid="stExpander"] * { color: #ffffff !important; }
        .stTextInput input, .stTextArea textarea { color: #ffffff !important; background-color: #161b22 !important; }
    </style>
    """, unsafe_allow_html=True)

    def main():
        st.title("Document Question Answering (RAG)")

        if "chunk_count" not in st.session_state:
            st.session_state.chunk_count = 0

        with st.sidebar:
            st.header("Settings")
            api_key = st.text_input("Google GenAI API Key", type="password", value=os.environ.get("GOOGLE_API_KEY", ""))
            uploaded_files = st.file_uploader("Upload Documents (PDF / DOCX / TXT)", type=["pdf", "docx", "txt"], accept_multiple_files=True)
            
            if st.button("Build Index", type="primary", use_container_width=True):
                if not uploaded_files:
                    st.warning("Please upload a file to build index.")
                else:
                    docs = []
                    for f in uploaded_files:
                        if f.name.endswith(".pdf"): docs.extend(MultiFormatIngestor.ingest_pdf(f, f.name))
                        elif f.name.endswith(".docx"): docs.extend(MultiFormatIngestor.ingest_docx(f, f.name))
                        elif f.name.endswith(".txt"): docs.extend(MultiFormatIngestor.ingest_txt(f.read().decode("utf-8"), f.name))
                    
                    chunker = SentenceBoundaryChunker(target_chunk_size=500, overlap_chars=100)
                    chunks = chunker.chunk_documents(docs)
                    vstore = SimpleVectorStore()
                    vstore.add_documents(chunks)
                    
                    st.session_state.retriever = HybridRRFRetriever(vstore, chunks)
                    st.session_state.chunk_count = len(chunks)
                    st.success(f"Successfully indexed {len(chunks)} chunks!")

        if "retriever" not in st.session_state:
            st.info("Upload your document in the sidebar and click 'Build Index' to start asking questions.")
        else:
            st.success(f"System Ready! {st.session_state.chunk_count} chunks indexed.")
            
            if "messages" not in st.session_state:
                st.session_state.messages = []

            for msg in st.session_state.messages:
                with st.chat_message(msg["role"]):
                    st.markdown(msg["content"])

            if query := st.chat_input("Ask a question about your document..."):
                st.session_state.messages.append({"role": "user", "content": query})
                with st.chat_message("user"):
                    st.markdown(query)

                with st.chat_message("assistant"):
                    engine = GroundedRAGAnswerEngine(api_key=api_key)
                    answer, chunks = engine.generate_answer(query, st.session_state.retriever)
                    st.markdown(answer)
                    
                    with st.expander("Retrieved Context Chunks"):
                        for idx, c in enumerate(chunks, 1):
                            st.markdown(f"**Chunk {idx}** ({c.metadata.get('source')}): {c.page_content}")
                    
                    st.session_state.messages.append({"role": "assistant", "content": answer})

if __name__ == "__main__":
    if st is not None:
        main()
