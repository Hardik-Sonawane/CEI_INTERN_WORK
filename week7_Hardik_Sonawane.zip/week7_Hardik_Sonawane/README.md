# Document Question Answering System (RAG Pipeline)

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

Welcome to **Week 7 v2**, a general-purpose Retrieval-Augmented Generation (RAG) system built to ingest custom documents (PDF, DOCX, TXT), perform hybrid vector and keyword search, and generate grounded answers using Google Gemini LLM.

---

## 🔑 Google GenAI API Key Setup

You can provide your **Google Gemini API Key** in either of the following two ways:

### Option A: In the Streamlit Dashboard UI
1. Launch the web application: `streamlit run app.py`
2. Open the **System Control Panel** sidebar on the left.
3. Paste your API key into the **Google GenAI API Key** password field.

### Option B: Environment Variable (Recommended for CLI / Notebooks)
Set your API key as an OS environment variable prior to launching the app or notebook:
- **Windows PowerShell**:
  ```powershell
  $env:GOOGLE_API_KEY="YOUR_GEMINI_API_KEY"
  ```
- **Linux / macOS Bash**:
  ```bash
  export GOOGLE_API_KEY="YOUR_GEMINI_API_KEY"
  ```

---

## Features

* **Multi-Format Document Ingestion**: Ingests PDF documents (`pypdf`), Word documents (`python-docx`), plain text (`.txt`), and Hugging Face Dataset archives (`datasets`).
* **Sentence-Aware Boundary Chunking**: Splits text into manageable chunks along sentence boundaries to preserve syntactic context.
* **Vector Representation & Indexing**: Maps chunked text into 384-dimensional vector representations stored in a fast Cosine Similarity vector store.
* **Hybrid RRF Retrieval Engine**: Combines BM25 keyword matching with vector search using Reciprocal Rank Fusion (RRF) and dynamic context re-ranking.
* **Grounded Answer Generation**: Prompts Google Gemini (`gemini-2.5-flash` / `gemini-2.0-flash`) using retrieved context chunks to generate grounded answers with source citations.
* **Interactive Dashboard & Notebook**: Features a Streamlit web interface (`app.py`) and a step-by-step Jupyter Notebook (`week7_Hardik_Sonawane.ipynb`) for continuous Q&A testing.

---

## System Architecture & Technical Specifications

### 1. Ingestion Module
Accepts custom text inputs including PDFs, raw text files, Word documents, or domain-specific Hugging Face archives.

### 2. Chunking Profile
- Strategy: `SentenceBoundaryChunker` (Sentence-aware natural boundary splitter)
- Target Chunk Size: 500 characters
- Sliding Overlap: 100 characters

### 3. Embeddings & Vector Store
- Vector Dimension: 384 dimensions
- Metric Space: L2 Cosine Distance
- Storage: NumPy Cosine Similarity Vector Store

### 4. Retrieval & LLM Setup
- Retrieval Strategy: Hybrid RRF Search (BM25 + Vector Similarity)
- LLM Engine: Google Gemini API via native `google-genai` SDK
- Temperature: 0.1

---

## How to Run

### 1. Set Up Environment & Install Dependencies
```bash
cd "c:/Users/tusha/OneDrive/Documents/celebal/week7v2"
pip install -r requirements.txt
```

### 2. Launch the Streamlit Application
```bash
streamlit run app.py
```

### 3. Run Jupyter Notebook Testing
Open `week7_Hardik_Sonawane.ipynb` in VS Code or Jupyter Notebook, set your document file path, and start asking grounded questions.

---

## Validation Logs

The system logs show accurate document extraction, hybrid retrieval scoring, and grounded QA performance:
```text
[INFO] Document Ingestion Complete: Ingested target document.
[INFO] Sentence Boundary Chunker: Created text chunks.
[INFO] Vector Store Indexing: Embedded chunks into 384-dimensional vector space.
[INFO] Hybrid RRF Retrieval: Query returned top contextually relevant document chunks.
[INFO] Gemini LLM Generation: Grounded answer generated with source citations.
```
